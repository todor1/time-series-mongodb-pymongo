# django-nextjs
Learn how to integrate Django with Next.js.

## Backend Code (Django + Django Ninja) is [here](https://github.com/codingforentrepreneurs/django-nextjs-backend-api)

## Frontend Code (Next.js) is [here](https://github.com/codingforentrepreneurs/django-nextjs-frontend)
