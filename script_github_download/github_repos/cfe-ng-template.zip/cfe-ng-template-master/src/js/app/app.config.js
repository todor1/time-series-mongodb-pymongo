'use strict';

angular.module('cfe').
    config(function(){});