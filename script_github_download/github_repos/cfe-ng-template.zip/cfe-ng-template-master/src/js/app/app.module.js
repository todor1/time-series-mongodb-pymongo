'use strict';

angular.module('cfe', [
    //external

    // internal
    'listView',

]);