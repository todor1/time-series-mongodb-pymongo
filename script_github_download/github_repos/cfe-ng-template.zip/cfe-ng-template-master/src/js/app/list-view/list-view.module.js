'use strict';

angular.module('listView', []);