# cfe-ng-template
An template for Coding for Entrepreneurs AngularJS projects
