# Coding for Entrepreneurs Blog
This repo will serve as a contributable copy of the blog hosted at 
https://www.codingforentrepreneurs.com/blog.

Be sure to check the _discussions_ tab if you have suggestions, questions, 
or recommendations!

Thank you for your feedback and contributions!
