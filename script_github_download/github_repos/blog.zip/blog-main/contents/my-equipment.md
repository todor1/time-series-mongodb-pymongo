---
title: My Equipment
slug: my-equipment

publish_timestamp: Sept. 1, 2016
url: https://www.codingforentrepreneurs.com/blog/my-equipment/

---


### Computer

Laptop: [http://amzn.to/2c965EL](http://amzn.to/2c965EL)

### Camera & Related

4k Camera: [http://amzn.to/2cb0JeS](http://amzn.to/2cb0JeS)
- Background Blur-effect Lens: [http://amzn.to/2d9EncV](http://amzn.to/2d9EncV)
- External Mic: [http://amzn.to/2cb0PTp](http://amzn.to/2cb0PTp)

Drone/Aerial Video: [http://amzn.to/2cCUgLq](http://amzn.to/2cCUgLq)

Flexible/Travel Tripod for DSLR: [http://amzn.to/2d13rXi](http://amzn.to/2d13rXi)
- I highly recommend this too: [http://amzn.to/2ckauYr](http://amzn.to/2ckauYr)

General Purpose Tripod: [http://amzn.to/2d4xNUS](http://amzn.to/2d4xNUS)

Webcam: [http://amzn.to/2bZEc7I](http://amzn.to/2bZEc7I)

### Studio

Mic: [http://amzn.to/2cCdNc3](http://amzn.to/2cCdNc3)

Mic Arm (for Studio):  [http://amzn.to/2cCepyd](http://amzn.to/2cCepyd)

Shock Mount (for Mic): [http://amzn.to/2c97uLN](http://amzn.to/2c97uLN)

### Mobile

Phone: [http://amzn.to/2c97R8X](http://amzn.to/2c97R8X)

Tablet (and portable external monitor): [http://amzn.to/2c5Fqdx](http://amzn.to/2c5Fqdx)

Headphones (mic used for travel recording): [http://amzn.to/2c5GGNO](http://amzn.to/2c5GGNO)

### Storage

External Hard drives: [http://amzn.to/2c5FvxV](http://amzn.to/2c5FvxV)
