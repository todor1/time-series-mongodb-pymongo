---
title: Srvup 2 is here
slug: srvup-2-is-here

publish_timestamp: Feb. 10, 2017
url: https://www.codingforentrepreneurs.com/blog/srvup-2-is-here/

---


The future of education will lean heavily on the internet and videos. Srvup 2 ([watch now](https://www.codingforentrepreneurs.com/projects/srvup-2/)) is a series to help you build your very own video membership site much like this one [CodingForEntrepreneurs.com](http://joincfe.com). 

Technology: 
- Django 1.10
- Python 3
- Bootstrap 3

[Watch](https://www.codingforentrepreneurs.com/projects/srvup-2/)
[Code](https://github.com/codingforentrepreneurs/Srvup-2)

This project has a *lot* more that will be added to it so get started [today](https://www.codingforentrepreneurs.com/projects/srvup-2/).

I can't wait to see what you build. 

Cheers!

Justin
