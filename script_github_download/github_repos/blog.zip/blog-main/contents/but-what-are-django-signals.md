---
title: But what are Django signals?
slug: but-what-are-django-signals

publish_timestamp: Jan. 27, 2021
url: https://www.codingforentrepreneurs.com/blog/but-what-are-django-signals/

---


Watch this one on [YouTube](https://www.youtube.com/watch?v=rEX50LJrFuU).
