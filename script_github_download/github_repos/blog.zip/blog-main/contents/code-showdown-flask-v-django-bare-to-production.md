---
title: Flask v Django: Bare to Production ~ Code Showdown
slug: code-showdown-flask-v-django-bare-to-production

publish_timestamp: Jan. 22, 2020
url: https://www.codingforentrepreneurs.com/blog/code-showdown-flask-v-django-bare-to-production/

---


Hey there,

In this video, I break down how to deploy a project on both Flask and Django. The point of this is to share how similar these two frameworks can be while also showing you their differences.

I call this a code showdown. This is the first one I've done so let me know what you think. Do you want to see more? What would you like to see?

Cheers!

Justin

<iframe width="560" height="315" src="https://www.youtube.com/embed/1_4ipYppIws" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
