---
title: How to add a watermark with overlays using OpenCV &amp; Python
slug: python-opencv-overlay-watermark

publish_timestamp: April 15, 2018
url: https://www.codingforentrepreneurs.com/blog/python-opencv-overlay-watermark/

---


Creating a watermark with OpenCV is not as straightforward as doing the same thing in something like Adobe photoshop. This video is all about how exactly you can set it up yourself and we'll dive deeper into how to access the exact pixel values in the entire video.

Enjoy!

<iframe width="560" height="315" src="https://www.youtube.com/embed/QjKmgdrNCP0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
