---
title: How to Apply Image Filters in OpenCV with Python
slug: how-to-apply-image-filters-in-opencv-with-python

publish_timestamp: April 19, 2018
url: https://www.codingforentrepreneurs.com/blog/how-to-apply-image-filters-in-opencv-with-python/

---


Add your own image filters on OpenCV and Python with this tutorial. 
We're building off techniques we used in previous videos in this [youtube playlist](https://www.youtube.com/playlist?list=PLEsfXFp6DpzRyxnU-vfs3vk-61Wpt7bOS).

Enjoy!

<iframe width="560" height="315" src="https://www.youtube.com/embed/MVLuexuikv4" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
