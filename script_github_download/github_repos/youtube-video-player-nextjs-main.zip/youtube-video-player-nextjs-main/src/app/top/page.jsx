import TopVideoTable from "./topVideoTable";


export default function TopVideoPage () {


    return <TopVideoTable />
}