[![Celery x Redis x Django Blog ost](https://static.codingforentrepreneurs.com/media/cfe-blog/celery-redis-django/setup_celery_redis_django.jpg)](https://www.codingforentrepreneurs.com/blog/celery-redis-django/)
# Django x Celery x Redis
Sample Repo for [Related Blog Post](https://www.codingforentrepreneurs.com/blog/celery-redis-django/)
