# cfe-redis-cli

A simple Docker container and Dockerfile for using the redis-cli command line tool.