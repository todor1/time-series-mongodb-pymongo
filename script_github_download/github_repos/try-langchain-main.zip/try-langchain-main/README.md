# Try LangChain
Learn how to use LangChain to build AI bots that can reason, use your data, and search the internet.


Watch the Try LangChain with Python and Upstash Vector tutorial now: 
https://youtu.be/FjKMnszG8Dk
