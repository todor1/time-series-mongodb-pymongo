

ACTIVATE_SCHEMA_SQL = 'SET search_path TO "{schema_name}";'

CREATE_SCHEMA_SQL = 'CREATE SCHEMA IF NOT EXISTS "{schema_name}";'


DROP_SCHEMA_SQL = 'DROP SCHEMA IF EXISTS "{schema_name}" CASCADE;'