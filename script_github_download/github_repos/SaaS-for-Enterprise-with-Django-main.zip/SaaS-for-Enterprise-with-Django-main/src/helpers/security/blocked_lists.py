BLOCKED_LIST = [
    "apple",
    "admin",
    "www",
    "blocked"
]