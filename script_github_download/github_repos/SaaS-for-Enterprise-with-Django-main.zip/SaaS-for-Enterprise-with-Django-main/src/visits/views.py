from django.shortcuts import render

# Create your views here.

# def page_visit_view(request):
#     PageVisit.objects.create(path='/', subdomain='www')
#     return HttpResponse("Hello")