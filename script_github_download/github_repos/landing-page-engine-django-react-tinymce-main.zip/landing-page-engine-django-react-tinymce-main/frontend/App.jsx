import './App.css'
import TinyMCE from './editor/tiny'

function App() {

  return <TinyMCE />
}

export default App
