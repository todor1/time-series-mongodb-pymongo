# Django <> Nextjs - Frontend


## Getting Started

Clone, install, then run:

```bash
git clone https://github.com/codingforentrepreneurs/django-nextjs-frontend

npm install

npm run dev
```