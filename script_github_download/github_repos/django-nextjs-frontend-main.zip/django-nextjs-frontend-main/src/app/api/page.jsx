"use server"

export default async function Page({ params, searchParams }) {
    return <h1>Api</h1>
  }