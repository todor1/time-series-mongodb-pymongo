# Datasets
To download the related datasets from this course, please visit the links below.

## Home Prices
https://www.kaggle.com/datasets/htagholdings/property-sales

##  Flight Prices
https://www.kaggle.com/datasets/justinmitchel/flightprices-min 
(fork of https://www.kaggle.com/datasets/dilwong/flightprices)