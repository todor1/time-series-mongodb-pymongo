
export default function FlightLayout({ children }) {
  return (
    <section>{children}</section>
  )
}
