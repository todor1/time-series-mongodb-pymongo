from .mixins import DefaultACLMixin

__all__ = [
    "DefaultACLMixin",
]
