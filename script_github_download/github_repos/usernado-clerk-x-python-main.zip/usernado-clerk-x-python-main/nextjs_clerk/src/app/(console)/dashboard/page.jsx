

export default function DashboardPage() {

    return <>
        <h1>Welcome to the dashboard</h1>
    </>
}