

export default function DashboardContactPage() {

    return <>
        <h1>Contact</h1>
    </>
}