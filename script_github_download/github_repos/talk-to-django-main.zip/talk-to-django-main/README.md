# Talk to Django
Talk to Django is simply a project that allows humans to make advanced queries to your Django project. In this you, will learn Semantic Search, Text to SQL, and Retrieval-Augmented Generation (aka RAG) with Django, Embeddings, Sentence Transformers, Neon Postgres Vector, Llama Index, OpenAI, Ollama, Llama 3.1, and more.
