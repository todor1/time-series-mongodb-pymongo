# Coding-with-Kafka

## Getting Started

If you're going through the course, do the following to start where we do:
```bash
mkdir -p ~/dev/coding-with-kakfa
cd ~/dev/coding-with-kakfa
git clone https://github.com/codingforentrepreneurs/Coding-with-Kafka .
git checkout start
rm -rf .git
git init
git commit -m "Course started!" 
```

