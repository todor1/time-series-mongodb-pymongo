# Gmail IMAP Parser

A Python script for easily parsing and fetching emails from Gmail using IMAP with flexible search options.

### Requirements
- Python 3
- Standard library only (no external dependencies)

## Setup

### 1. Enable Gmail App Password

1. Go to [Google Account Settings](https://myaccount.google.com/apppasswords)
2. Generate a new App Password for "Mail"
3. Save the 16-character password

### 2. Environment Variables

Set up your credentials as environment variables:

```bash
export GMAIL_EMAIL="your-email@gmail.com"
export GMAIL_APP_PASSWORD="your-16-char-app-password"
```

or a `.env`

```bash
GMAIL_EMAIL="your-email@gmail.com"
GMAIL_APP_PASSWORD="your-16-char-app-password"
```

## Quick Start

```python
import os
from gmail_imap_parser import GmailImapParser

# pip install python-dotenv
# from dotenv import load_dotenv
# load_dotenv()

# Initialize
parser = GmailImapParser(
    email_address=os.environ["GMAIL_EMAIL"],
    app_password=os.environ["GMAIL_APP_PASSWORD"]
)

# Fetch unread emails from last 24 hours
emails = parser.fetch_emails(hours=24, unread_only=True)

for email in emails:
    print(f"From: {email['from']}")
    print(f"Subject: {email['subject']}")
    print(f"Date: {email['timestamp']}")
    print("---")
```

## Usage Examples

### Time-Based Filtering

```python
# Last 3 hours
emails = parser.fetch_emails(hours=3)

# Last 7 days
emails = parser.fetch_emails(days=7)

# Last 30 minutes
emails = parser.fetch_emails(minutes=30)

# Specific date range
from datetime import datetime
emails = parser.fetch_emails(
    start_date=datetime(2024, 1, 1),
    end_date=datetime(2024, 1, 31)
)
```

### Sender Filtering

```python
# Emails from specific sender
emails = parser.fetch_emails(
    hours=24,
    from_email="noreply@github.com"
)

# Multiple criteria
emails = parser.fetch_emails(
    days=7,
    from_email="alerts@service.com",
    unread_only=True,
    keep_unread=True  # Don't mark as read
)
```

### Folder Operations

```python
# List all available folders
folders = parser.list_gmail_folders()
print("Available folders:", folders)

# Search specific folder
emails = parser.fetch_emails(
    folder="[Gmail]/Sent Mail",
    days=3
)

# Search all folders
all_emails = parser.fetch_emails(
    hours=6,
    search_all_folders=True
)
```

### Advanced Usage

```python
# Debug search issues
debug_info = parser.debug_search_comparison(
    hours=24,
    from_email="sender@example.com"
)

# Get comprehensive email data
emails = parser.fetch_emails_comprehensive(
    days=1,
    from_email="notifications@app.com"
)

# Mark emails as unread
email_ids = [email['uid'] for email in emails]
parser.mark_emails_as_unread(email_ids)
```

## API Reference

### GmailImapParser

#### Constructor
```python
GmailImapParser(email_address: str, app_password: str)
```

#### Main Methods

**`fetch_emails(**kwargs) -> List[Dict]`**
- Fetch emails with flexible filtering options
- **Parameters:**
  - `hours/days/minutes` (int): Time period to search
  - `start_date/end_date` (datetime|str): Specific date range
  - `from_email` (str): Filter by sender
  - `folder` (str): Specific folder to search
  - `unread_only` (bool): Only unread emails
  - `keep_unread` (bool): Don't mark emails as read
  - `search_all_folders` (bool): Search across all folders
  - `verbose` (bool): Debug output

**`list_gmail_folders(verbose=False) -> List[str]`**
- List all available Gmail folders/labels

**`fetch_emails_comprehensive(**kwargs) -> List[Dict]`**
- Fetch emails with full content extraction

### Email Data Structure

Each email is returned as a dictionary with:

```python
{
    'uid': '12345',                    # Unique identifier
    'from': 'sender@example.com',      # Sender email
    'subject': 'Email Subject',        # Subject line
    'timestamp': datetime_object,      # When received
    'date_str': 'Mon, 01 Jan 2024',   # Formatted date
    'to': ['recipient@example.com'],   # Recipients
    'cc': ['cc@example.com'],          # CC recipients
    'body_text': 'Plain text...',      # Plain text body
    'body_html': '<html>...</html>',   # HTML body
    'has_attachments': True,           # Has attachments
    'attachment_count': 2,             # Number of attachments
    'attachment_filenames': ['file.pdf'], # Attachment names
    'folder': 'INBOX'                  # Source folder
}
```

## Troubleshooting

### Common Issues

**Authentication Failed**
- Verify App Password is correct (16 characters, no spaces)
- Ensure 2-Factor Authentication is enabled on Google Account
- Check that "Less secure app access" is not required

**No Emails Found**
- Use `verbose=True` to see search criteria
- Try `debug_search_comparison()` to troubleshoot filters
- Verify folder names with `list_gmail_folders()`
- Check date ranges and time zones

**Connection Issues**
- Ensure internet connectivity
- Check if Gmail IMAP is enabled in settings
- Verify firewall/proxy settings

### Debug Mode

Enable verbose logging for troubleshooting:

```python
emails = parser.fetch_emails(
    hours=24,
    verbose=True  # Shows search criteria and connection info
)
```

### Advanced Debugging

```python
# Compare searches with/without filters
debug_info = parser.debug_search_comparison(
    hours=24,
    from_email="sender@example.com"
)

# Show all emails from sender (up to limit)
all_sender_emails = parser.debug_all_emails_from_sender(
    from_email="sender@example.com",
    limit=50
)
```

## Examples Directory

Check out the example script in the repository for complete working examples:

```python
import os
from gmail_imap_parser import GmailImapParser

EMAIL = os.environ.get("GMAIL_EMAIL", 'your-email@gmail.com')
APP_PASSWORD = os.environ.get("GMAIL_APP_PASSWORD")

def main():
    """Main function demonstrating various usage patterns."""
    
    parser = GmailImapParser(EMAIL, APP_PASSWORD)
    
    # List folders
    print("=== Available Folders ===")
    folders = parser.list_gmail_folders(verbose=False)
    for folder in folders:
        print(f"📁 {folder}")
    
    # Fetch recent unread emails
    print("\n=== Unread Emails (Last 3 Hours) ===")
    emails = parser.fetch_emails(
        hours=3, 
        from_email='no-reply@accounts.google.com', 
        folder='INBOX', 
        keep_unread=True,
        verbose=False,
    )
    
    for msg in emails:
        print(f"🆔 ID: {msg.get('uid')}")
        print(f"📧 From: {msg['from']}")
        print(f"📝 Subject: {msg['subject']}")
        print(f"⏰ Timestamp: {msg['timestamp']}")
        print("─" * 50)

if __name__ == "__main__":
    main()
```

## Security Considerations

- Never commit App Passwords to version control
- Use environment variables or secure credential management
- Rotate App Passwords periodically
- Monitor Gmail account activity for unauthorized access

## License

[Add your license information here]

## Contributing

[Add contributing guidelines here]

## Support

For issues and questions:
- Check the troubleshooting section above
- Use verbose mode for debugging
- Report bugs with detailed error messages and search criteria used