#!/usr/bin/env python3
"""
Simple example of GmailImapParser usage.
"""

import os
import sys
import random
from dotenv import load_dotenv
from datetime import datetime, timedelta

# Add the parent directory to Python path to import gmail_imap_parser package
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from gmail_imap_parser import GmailImapParser

def main():
    # Load credentials
    load_dotenv()
    email_address = os.getenv("GMAIL_EMAIL")
    app_password = os.getenv("GMAIL_APP_PASSWORD")
    use_random_folder = False
    
    if not email_address or not app_password:
        print("Please set GMAIL_EMAIL and GMAIL_APP_PASSWORD in .env file")
        return
    
    
    # Create parser and get recent emails
    parser = GmailImapParser(email_address, app_password)

    folders = parser.list_gmail_folders(verbose=False)

    search_folder = random.choice(folders) if use_random_folder else '[Gmail]/All Mail'
    
    # First, let's try with a folder that we know exists
    start_date = datetime.now() - timedelta(weeks=10)
    end_date = datetime.now() - timedelta(weeks=5)
    print(f"Fetching emails from {search_folder} from {start_date} to {end_date}")
    try:
        # Get emails from specified date range - try [Gmail]/All Mail
        emails = parser.fetch_emails(start_date=start_date, folder=search_folder, end_date=end_date, unread_only=False, verbose=True)
        
        print(f"\nFound {len(emails)} emails:")
        for email in emails[:5]:  # Show first 5
            print(f"From: {email.get('from')}")
            print(f"Subject: {email.get('subject')}")
            print(f"Date: {email.get('timestamp')}")
            print("---")
            
    except Exception as e:
        print(f"Error: {e}")
    finally:
        parser.disconnect()

if __name__ == "__main__":
    main() 