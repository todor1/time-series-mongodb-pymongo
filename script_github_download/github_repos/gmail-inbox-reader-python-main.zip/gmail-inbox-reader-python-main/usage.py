#!/usr/bin/env python3
"""
Simple example of GmailImapParser usage.
"""

import os
import sys
import random
from dotenv import load_dotenv
from datetime import datetime, timedelta

# Add the gmail_imap_parser directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'gmail_imap_parser'))

from gmail_imap_parser import GmailImapParser

def main():
    # Load credentials
    load_dotenv()
    email_address = os.getenv("GMAIL_EMAIL")
    app_password = os.getenv("GMAIL_APP_PASSWORD")
    
    if not email_address or not app_password:
        print("Please set GMAIL_EMAIL and GMAIL_APP_PASSWORD in .env file")
        return
    
    # Create parser and get recent emails
    parser = GmailImapParser(email_address, app_password)
    print(f"Fetching emails")
    try:
        # Get emails from specified date range - try [Gmail]/All Mail
        emails = parser.fetch_emails(days=10, unread_only=False, verbose=True)
        
        print(f"\nFound {len(emails)} emails:")
        for email in emails[:5]:  # Show first 5
            print(f"From: {email.get('from')}")
            print(f"Subject: {email.get('subject')}")
            print(f"Date: {email.get('timestamp')}")
            print("---")
            
    except Exception as e:
        print(f"Error: {e}")
    finally:
        parser.disconnect()

if __name__ == "__main__":
    main() 