from django.apps import AppConfig


class YourappConfig(AppConfig):
    name = 'yourapp'
