# AJAXify Django Forms

This code is reference to the step-by-step guide: [https://kirr.co/r1tsdb](https://kirr.co/r1tsdb)

[![AJAXify Django Forms Logo](https://cfe2-static.s3-us-west-2.amazonaws.com/media/cfe-blog/ajaxify-django-forms/AJAXify_Django_Form.jpg)](https://kirr.co/r1tsdb)