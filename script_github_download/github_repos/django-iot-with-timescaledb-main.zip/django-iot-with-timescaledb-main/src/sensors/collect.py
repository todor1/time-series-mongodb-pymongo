import random 

def get_random_temp():
    return random.uniform(0.0, 130.0) # f