# AI as an API Course Reference
This repository is the exact code used in the course. For the complete &amp; most up to date project go to https://github.com/codingforentrepreneurs/AI-as-an-API

The final working (and production version) of the code is [here](https://github.com/codingforentrepreneurs/AI-as-an-API).
