from django.apps import AppConfig


class TopicsConfig(AppConfig):
    name = 'topics'
