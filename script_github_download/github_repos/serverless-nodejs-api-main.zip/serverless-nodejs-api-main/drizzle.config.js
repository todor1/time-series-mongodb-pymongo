const config = {
    schema: './src/db/schemas.js',
    out: './src/migrations'
}

export default config