
# Should I update this course? 

Yes? Show your support by starring this repo! ⭐️

[![Star this repo](https://img.shields.io/github/stars/codingforentrepreneurs/Try-Reactjs?style=social)](https://github.com/codingforentrepreneurs/Try-Reactjs)

When I wrote this, there were 94 stars. I'll check back soon to see if we need a revamp. Your star could make the difference!

[View Stargazers](https://github.com/codingforentrepreneurs/Try-Reactjs/stargazers)


## Try Reactjs
Learn Reactjs bit by bit and subscribe to get everything on [joincfe.com/youtube/](http://joincfe.com/youtube/)

Do you need a particular topic covered? Be sure to [subscribe](http://joincfe.com/youtube/) and leave a comment on any video on the [playlist](https://kirr.co/e0nybk)

### Links
- [All Code](https://kirr.co/cgl4ih)
- [Try React Playlist](https://kirr.co/e0nybk)
- [Setup React](https://kirr.co/1m68l5)
- This repo https://github.com/codingforentrepreneurs/Try-Reactjs
- 2021 version [here](https://github.com/codingforentrepreneurs/Try-React.js) and [here](https://www.codingforentrepreneurs.com/projects/try-reactjs-2021)
