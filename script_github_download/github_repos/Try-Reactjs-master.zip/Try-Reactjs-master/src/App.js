import React, { Component } from 'react'
// import PostSorting from './posts/PostSorting'
import './App.css'

import ImgDropAndCrop from './learn/ImgDropAndCrop'

class App extends Component {
  render () {
    return (
      <div className='App'>
        <ImgDropAndCrop />
      </div>
    )
  }
}

export default App
