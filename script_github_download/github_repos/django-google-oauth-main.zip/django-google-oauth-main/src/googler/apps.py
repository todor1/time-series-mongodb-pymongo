from django.apps import AppConfig


class GooglerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'googler'
