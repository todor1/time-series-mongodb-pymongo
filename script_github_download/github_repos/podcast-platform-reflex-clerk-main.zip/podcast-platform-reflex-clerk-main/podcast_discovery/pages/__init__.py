from .about import about_page
from .pricing import pricing_page

__all__ = [
    "about_page",
    "pricing_page",
]