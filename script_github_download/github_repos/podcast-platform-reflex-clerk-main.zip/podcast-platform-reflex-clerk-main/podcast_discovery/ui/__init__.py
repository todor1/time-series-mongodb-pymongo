from .headings import (
    page_heading
)


__all__ = [
    "page_heading"
]