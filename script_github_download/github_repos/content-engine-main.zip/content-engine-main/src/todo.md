projects -> group of assets and people and planning
    items -> 
        -> assets -> files, videos, images,
        -> planning -> status, pre-filming
        -> delivery -> ??
    access->
        -> project users