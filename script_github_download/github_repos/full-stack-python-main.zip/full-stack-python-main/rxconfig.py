import reflex as rx

config = rx.Config(
    app_name="full_stack_python",
    db_url="sqlite:///reflex.db", 
)