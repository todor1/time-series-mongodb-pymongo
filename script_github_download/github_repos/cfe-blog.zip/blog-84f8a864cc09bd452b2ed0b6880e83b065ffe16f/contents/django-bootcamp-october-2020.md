---
title: Django Bootcamp - October 2020
slug: django-bootcamp-october-2020

publish_timestamp: Oct. 1, 2020
url: https://www.codingforentrepreneurs.com/blog/django-bootcamp-october-2020/

---


Learn Django little by little in my live [Django bootcamp](https://www.youtube.com/playlist?list=PLEsfXFp6DpzT-1RVQVsL7C2XGMeQzfqAL):

<iframe width="560" height="315" src="https://www.youtube.com/embed/videoseries?list=PLEsfXFp6DpzT-1RVQVsL7C2XGMeQzfqAL" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

Be sure to [subscribe](https://cfe.sh/youtube) for all live events.

Cheers!
