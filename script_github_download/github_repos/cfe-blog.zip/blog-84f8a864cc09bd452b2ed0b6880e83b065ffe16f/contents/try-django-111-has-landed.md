---
title: Try Django 1.11 has landed.
slug: try-django-111-has-landed

publish_timestamp: July 5, 2017
url: https://www.codingforentrepreneurs.com/blog/try-django-111-has-landed/

---


Learn Django Basics in the Try Django Tutorial Series. This series is a step-by-step tutorial covering the basics of the Django web framework. 

All reference code is [here](https://github.com/codingforentrepreneurs/Try-Django-1.11)
-------

On [CFE](https://www.codingforentrepreneurs.com/projects/try-django-111):
[![Try Django Logo](https://cfe2-static.s3-us-west-2.amazonaws.com/media/projects/try-django-111/images/share/try_django_1_11_share_sm.jpg)](https://www.codingforentrepreneurs.com/projects/try-django-111/)
-------
On [YouTube](https://youtu.be/yDv5FIAeyoY):
<iframe width="560" height="315" src="https://www.youtube.com/embed/yDv5FIAeyoY" frameborder="0" allowfullscreen></iframe>
