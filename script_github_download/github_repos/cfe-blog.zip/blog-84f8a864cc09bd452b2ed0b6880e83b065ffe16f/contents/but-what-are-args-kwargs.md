---
title: But what are *args &amp; **kwargs?
slug: but-what-are-args-kwargs

publish_timestamp: Jan. 25, 2021
url: https://www.codingforentrepreneurs.com/blog/but-what-are-args-kwargs/

---


[[ youtube id="GdSJAZDsCZA"  ]]
