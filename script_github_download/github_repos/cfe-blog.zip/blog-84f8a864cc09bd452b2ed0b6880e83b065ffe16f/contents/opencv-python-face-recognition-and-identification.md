---
title: OpenCV &amp; Python: Face Recognition and Identification
slug: opencv-python-face-recognition-and-identification

publish_timestamp: April 11, 2018
url: https://www.codingforentrepreneurs.com/blog/opencv-python-face-recognition-and-identification/

---


I'm really starting to enjoy working with OpenCV. 

In this one, we implement a simple way to recognize faces and run training on a variety of known images for face identification all using just OpenCV. 

Check it out:

<iframe width="560" height="315" src="https://www.youtube.com/embed/PmZ29Vta7Vc" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

New to OpenCV? Start [here](https://www.codingforentrepreneurs.com/blog/opencv-python-web-camera-quick-test/).
