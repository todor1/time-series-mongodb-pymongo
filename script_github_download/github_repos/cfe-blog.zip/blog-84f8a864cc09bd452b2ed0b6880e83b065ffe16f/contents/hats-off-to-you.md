---
title: Hats off to you...
slug: hats-off-to-you

publish_timestamp: Jan. 20, 2017
url: https://www.codingforentrepreneurs.com/blog/hats-off-to-you/

---


CFE Community!

Hats off to you for all your hard work and dedication. We love hearing from our students' experience and the last few weeks have been amazing. You guys are really building some awesome stuff and I'm honored to be apart of it all.

I can't wait for what 2017 has to bring. Big stuff for [content](https://www.codingforentrepreneurs.com/blog/coming-soon-2017/) in our pipeline and some other areas we are researching too! More on that later.

In the meantime, we've made some improvements to the site to help the user experience:

- Autoplay on Desktop (mobile devices disable this for web)
- Improved video controls including speed support.
- Improved Search
- Added Comments to Blogs
- Introducing "Messenger Beta" to message your friends on CFE
- Added public profiles with user profile images.
- Update notifications
- Improved ease of sharing projects with friends

These are just some of the many upgrades we've made to Coding For Entrepreneurs. As always, we're building the best possible service with one goal in mind: help you learn and launch your projects.

Thank you.

Cheers!

Justin
