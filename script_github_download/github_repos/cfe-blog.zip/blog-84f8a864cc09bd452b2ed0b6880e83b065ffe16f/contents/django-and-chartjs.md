---
title: Django + Chart.js
slug: django-and-chartjs

publish_timestamp: March 2, 2017
url: https://www.codingforentrepreneurs.com/blog/django-and-chartjs/

---


Learn how to integrate Charts.js with Django.

We show you how to integrate:
[Chart.js](http://www.chartjs.org/) with [Django](http://django.project.com) and the [Django Rest Framework](http://www.django-rest-framework.org/)

What to see more Chart.js? Submit & Upvote [here](http://joincfe.com/suggest/)

Subscribe to our YouTube channel: [http://joincfe.com/youtube/](http://joincfe.com/youtube/)

<iframe width="560" height="315" src="https://www.youtube.com/embed/B4Vmm3yZPgc" frameborder="0" allowfullscreen></iframe>
