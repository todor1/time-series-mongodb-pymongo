AWS + CFE
=========
### [Amazon Web Services](http://aws.amazon.com) (AWS) +
### [Coding for Entrepreneurs](http://www.codingforentrepreneurs.com) (CFE)

This repo is related source code for the following projects:


### [Elastic Beanstalk](https://codingforentrepreneurs.com/projects/elastic-beanstalk/)
![Elastic Beanstalk](https://cfe-static.s3.amazonaws.com/media/amazon-s3-django/images/s3_django.png)

======

### [Amazon S3 & Django](https://codingforentrepreneurs.com/projects/amazon-s3-django/)
![Amazon S3 & Django](https://cfe-static.s3.amazonaws.com/media/elastic-beanstalk/images/aws_eb.png)
